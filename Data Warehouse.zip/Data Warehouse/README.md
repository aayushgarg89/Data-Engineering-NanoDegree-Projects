Purpose: The purpose of this project is to build an ETL pipeline that extracts their data from S3, stages them in Redshift, and transforms data into a set of dimensional tables for Sparkify's analytics team to continue finding insights in what songs their users are listening to

The best datawarehouse design for this scenario is the Star Schema design with 1 fact table and multiple dimension tables:

-sql_queries.py  
           - this file consists of the DROP, CREATE and INSERT SQL statements for 1 fact table and 4 dimension tables
                   - fact table : songplays
                   - dimension tables : users
                                        song
                                        artists
                                        time
           - the file also contains DROP, CREATE and INSERT into Staging tables as follows:
                   - stage_events: takes the json data from S3 bucket udacity-dend/log_data and inserts into this table using COPY
                   - stage_songs : takes the json data from S3 bucket udacity-dend/song_data and inserts into this table using COPY
                   
-create_tables.py
            - this file connects to the Redshift cluster and drop all the fact, dimension and staging tables if it exist and create
                these tables if they donot exist

-etl.py
            - this file connects to the redshift cluster and first load all the staging tables and then insert the data into fact and
                dimension tables using the data in staging tables

-dwh.cfg
            - this is the configuration file that contains the redshift cluster details(host,database,username,password and port) 
                to connect to redshift, IAM user role with the permissions to access the S3 bucket and S3 details where the json
                files for the log data and song data is present.


Sample output for the songplays data:

query: select * from songplays limit 10;

result:
songplay_id	start_time	user_id	level	song_id	artist_id	session_id	location	user_agent
54	11/5/2018 5:57	57	free	SOCGOZK12A8151BD5D	ARM0P6Z1187FB4D466	56	San Antonio-New Braunfels, TX	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/534.59.10 (KHTML, like Gecko) Version/5.1.9 Safari/534.59.10"
79	11/2/2018 18:36	71	free	SOBBZPM12AB017DF4B	ARH6W4X1187B99274F	70	Columbia, SC	"Mozilla/5.0 (iPhone; CPU iPhone OS 7_1_1 like Mac OS X) AppleWebKit/537.51.2 (KHTML, like Gecko) Version/7.0 Mobile/11D201 Safari/9537.53"
284	11/4/2018 7:31	25	paid	SOHWVJJ12AB0185F6D	ARASYMJ1187B9ACAF2	128	Marinette, WI-MI	"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36"
93	11/4/2018 6:51	25	paid	SORKKTY12A8C132F3E	ARIH5GU1187FB4C958	128	Marinette, WI-MI	"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36"
330	11/28/2018 11:38	82	paid	SOIZLKI12A6D4F7B61	ARR3ONV1187B9A2F59	140	Atlanta-Sandy Springs-Roswell, GA	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.94 Safari/537.36"
78	11/5/2018 18:00	97	paid	SOTUWPH12AB017DEBC	ARGLI7X1187B9930BB	147	Lansing-East Lansing, MI	"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.94 Safari/537.36"
110	11/5/2018 15:43	97	paid	SODHZVG12A8C1404DD	ARS5WKC1187B9AC7D1	147	Lansing-East Lansing, MI	"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.94 Safari/537.36"
306	11/5/2018 17:31	35	free	SONTFNG12A8C13FF69	AR52EZT1187B9900BF	171	St. Louis, MO-IL	"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.94 Safari/537.36"
212	11/4/2018 15:39	78	free	SOBONKR12A58A7A7E0	AR5E44Z1187B9A1D74	176	Indianapolis-Carmel-Anderson, IN	Mozilla/5.0 (Windows NT 6.1; rv:31.0) Gecko/20100101 Firefox/31.0
250	11/7/2018 1:42	8	free	SOWTZNU12AB017EADB	AR6NYHH1187B9BA128	181	Phoenix-Mesa-Scottsdale, AZ	"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36"

