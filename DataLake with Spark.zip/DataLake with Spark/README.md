Purpose:
The purpose of this project is to learn how to extract .json files from S3, process them with Spark and loads the data back into S3 as a set of dimension tables.

There are 2 types of datasets that Sparkify collects to find insights on what users are listening to:
1. Song Data: Stored in udacity-dend bucket and song_data folder in S3
2. Log Data: Stored in the same udacity-dend and log_data folder in S3

This projects creates a set of 1 fact and 4 dimension tables in a form of star schema as follows:

Fact Table : 
            songplays - records in log data associated with song plays i.e. records with page NextSong
                        songplay_id, start_time, user_id, level, song_id, artist_id, session_id, location, user_agent
                        
Dimension Tables :
            users - users in the app
                    user_id, first_name, last_name, gender, level
            songs - songs in music database
                    song_id, title, artist_id, year, duration
            artists - artists in music database
                    artist_id, name, location, lattitude, longitude
            time - timestamps of records in songplays broken down into specific units
                    start_time, hour, day, week, month, year, weekday


Files in the repository:

1. dl.cfg - This is the configuration file that is used to store the access key and secret access key to establish the connection to the public bucket of S3 where song datasets and log datasets resides.

2. etl.py - This is the python file that access the song dataset to create 'songs' and 'artists' dimension tables and access the log dataset to create 'users' dimension table. The 'time' dimension table is created based on 'ts' column in log dataset which is the unix timestamp column. This column is converted into the regular date time column and then specifics such as year, month, day, week,etc. are extracted from the date time column to make time dimension table. The fact table 'SongPlays' is then created by joining the song dataset and log dataset on the song name column. All the fact and dimension tables are then stored back into S3 in the form of 'Parquet' files.

How to run the project:

1. Go the console and type 'run etl.py' : 

It takes the access key and secret access key to access the public bucket of S3 from dl.cfg configuration file. Then it runs the function 'Process_song_data' that takes input spark session, input data(eg:#song_data = input_data + "song_data/A/A/A/TRAAAAK128F9318786.json") to read the song json files and output data to write to S3 in parquet format. Then it runs the function 'Process_log data' that takes the inout spark session, input data (eg:#log_data =input_data + "log_data/2018/11/2018-11-12-events.json") to read the log json files and output data to write back to S3 in parquet format.
