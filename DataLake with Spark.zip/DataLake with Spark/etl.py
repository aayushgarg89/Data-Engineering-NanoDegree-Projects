import configparser
from datetime import datetime
import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import udf, col, row_number
from pyspark.sql.functions import year, month, dayofmonth, hour, weekofyear, date_format, to_timestamp, from_utc_timestamp, from_unixtime
from pyspark.sql.types import TimestampType

config = configparser.ConfigParser()
config.read_file(open('dl.cfg'))

os.environ['AWS_ACCESS_KEY_ID']=config['AWS']['AWS_ACCESS_KEY_ID']
os.environ['AWS_SECRET_ACCESS_KEY']=config['AWS']['AWS_SECRET_ACCESS_KEY']

def create_spark_session():
    spark = SparkSession \
        .builder \
        .config("spark.jars.packages", "org.apache.hadoop:hadoop-aws:2.7.0") \
        .getOrCreate()
    return spark

def process_song_data(spark, input_data, output_data):
    '''
    Reads various json files stored in S3://udacity-dend/song_data folder and creates 'song' and 'artist' dimension tables
    
    Arguments:
    spark: instantiate the spark session
    input_data: specifies the S3 bucket to read song_data .json files
    output_data: specifies the S3 bucket to write 'song' and 'artist' dimension tables
    
    returns:
        'Songs' dimension table in parquet format and partitioned by year and artist
        'artists' dimesion table in parquet format
    '''
    song_data = input_data + "song_data/*/*/*/*.json"
    df = spark.read.json(song_data)
    df.createOrReplaceTempView("song_data_table")
    songs_table = spark.sql('''
                            SELECT DISTINCT(song_id),title,artist_id,year,duration
                            FROM song_data_table
                            ''')
    songs_table.write.mode('overwrite').partitionBy('year','artist_id').parquet(output_data+'songs')
    artists_table = spark.sql('''
                              SELECT DISTINCT(artist_id),artist_name,artist_location,artist_longitude,artist_latitude
                              FROM song_data_table
                              ''')
    artists_table.write.mode('overwrite').parquet(output_data +'artists')



def process_log_data(spark, input_data, output_data):
    '''
    Reads various json files stored in S3://udacity-dend/log_data folder and create 'users' and 'time' dimension tables.
    Also creates 'Songplays' fact table by joining log_time_table view and song_data_temp_table view.
    
    Arguments:
    spark: instantiate the spark session
    input_data: specifies the S3 bucket to read log_data .json files
    output_data: specifies the S3 bucket to write 'users' and 'time' dimension tables and 'songsplay' fact table
    
    returns:
        'users' dimension table in parquet format
        'time' dimesion table in parquet format and partitioned by year and month
        'songplays' fact table in parquet format and partioned by year and month
    '''
    log_data =input_data +"log_data/*/*/*.json"
    df =spark.read.json(log_data)
    df = df.filter("page='NextSong'")
    df.createOrReplaceTempView('log_data_table')    
    users_table =spark.sql('''
                                SELECT distinct(userid),firstName,lastName,gender,level
                                FROM log_data_table
                                ''')
    users_table.write.mode('overwrite').parquet(output_data+'users')

    
    get_timestamp = udf(lambda x: datetime.fromtimestamp(
        (x/1000.0)), TimestampType())
    dfTime = df.withColumn('start_time', get_timestamp('ts'))
    dfTime=dfTime.withColumn("year",year("start_time"))\
                 .withColumn("month",month("start_time"))\
                 .withColumn("day",dayofmonth("start_time"))\
                 .withColumn("hour",hour("start_time"))\
                 .withColumn("week",weekofyear("start_time"))\
                 .withColumn("weekday",date_format(col("start_time"),"EEEE"))
    dfTime.createOrReplaceTempView("log_time_table")
    time_table =spark.sql('''
                            SELECT start_time,year,month,day,hour,week,weekday
                            FROM log_time_table
                            ''') 
    time_table.write.mode('overwrite').partitionBy('year','month').parquet(output_data +'time')


    song_df =spark.read.json(input_data + "song_data/*/*/*/*.json")
    song_df.createOrReplaceTempView("song_data_temp_table") 
    songplays_table =spark.sql('''
                                SELECT ROW_NUMBER() OVER (order by start_time) as songPlay_id
                                        ,ltt.start_time
                                        ,ltt.userid
                                        ,ltt.level
                                        ,sdtt.song_id
                                        ,sdtt.artist_id
                                        ,ltt.sessionId
                                        ,ltt.location
                                        ,ltt.userAgent
                                        ,ltt.year as year
                                        ,ltt.month as month
                                FROM log_time_table ltt
                                LEFT OUTER JOIN song_data_temp_table sdtt 
                                    ON ltt.song=sdtt.title
                                ''') 
    songplays_table.write.mode('overwrite').partitionBy('year','month').parquet(output_data+'songplays')


def main():
    spark = create_spark_session()
    input_data = "s3a://udacity-dend/"
    output_data = "s3a://Project_DataLake/"
    
    process_song_data(spark, input_data, output_data)    
    process_log_data(spark, input_data, output_data)


if __name__ == "__main__":
    main()
