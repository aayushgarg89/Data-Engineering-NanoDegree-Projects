from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults

class LoadDimensionOperator(BaseOperator):

    ui_color = '#80BD9E'

    @apply_defaults
    def __init__(self,
                 redshift_conn_id="",
                 sql_statement="",
                 table="",
                 append_data="",
                 *args, **kwargs):

        super(LoadDimensionOperator, self).__init__(*args, **kwargs)
        self.redshift_conn_id=redshift_conn_id
        self.sql_statement=sql_statement
        self.table=table
        self.append_data=append_data

    def execute(self, context):
        redshift=PostgresHook(postgres_conn_id=self.redshift_conn_id)
        
        if self.append_data==True:
            self.log.info("inserting data into Redshift table")
            sql_query='INSERT INTO {} {}'.format(self.table,self.sql_statement)
            redshift.run(sql_query)
        else:
            self.log.info("clearing data from the Redshift table")
            sql_query = 'DELETE FROM {}'.format(self.table)
            redshift.run(sql_query)
            self.log.info("inserting data into Redshift table")
            sql_query='INSERT INTO {} {}'.format(self.table,self.sql_statement)
            redshift.run(sql_query)
