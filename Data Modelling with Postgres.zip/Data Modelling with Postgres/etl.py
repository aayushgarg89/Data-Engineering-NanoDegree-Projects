import os
import glob
import psycopg2
import pandas as pd
from sql_queries import *


def process_song_file(cur, filepath):
    '''This function processes the song file and insert the data from each file
        into song dimension table- song id,title,artist_id,year and duration  
        and into artists table- artist id, artist name, artist location, artist latitude and artist longitude'''
    df = pd.read_json(filepath,lines=True)
    song_data = df[['song_id','title','artist_id','year','duration']].values.tolist()
    song_data = [ item for elem in song_data for item in elem]
    cur.execute(song_table_insert, song_data)
    artist_data = df[['artist_id','artist_name','artist_location','artist_latitude','artist_longitude']].values.tolist()
    artist_data=[item for elem in artist_data for item in elem] 
    cur.execute(artist_table_insert, artist_data)


def process_log_file(cur, filepath):
    '''this function processes the log file for all the users that went to next song and not logged out by
        listening to only 1 song.this file inserts the data into time dimension table - start time(ts),
        to_datetime() breaks the start time to datetime structure and then different elements are inserted.
        Also inserts data into user dimension table -user id, first name, last name, gender,level-free or paid'''
    df = pd.read_json(filepath,lines=True)
    df_NextSong=df['page']=='NextSong'
    df = df[df_NextSong]
    t = pd.to_datetime(df['ts'], unit='ms')
    time_data = [t,t.dt.hour,t.dt.day,t.dt.week,t.dt.month,t.dt.year,t.dt.dayofweek]
    column_labels = ['start_time','hour','day','week','month','year','weekday']
    time_df = pd.DataFrame(dict(zip(column_labels, time_data)))

    for i, row in time_df.iterrows():
        cur.execute(time_table_insert, list(row))

    
    user_df = df[['userId','firstName','lastName','gender','level']]

    
    for i, row in user_df.iterrows():
        cur.execute(user_table_insert, row)

    '''below is the process of building fact table songplays. first getting the artist id and the song id for 
    each song, artist and length of the song, is achieved by joining artist and songs table and filtering
    on the these columns. then inserting the data into songplays fact table'''
    
    for index, row in df.iterrows():
        
        
        cur.execute(song_select, (row.song, row.artist, row.length))
        results = cur.fetchone()
        
        if results:
            songid, artistid = results
        else:
            songid, artistid = None, None

        
        songplay_data =[int(row.ts),int(row.userId),row.level,songid,artistid,row.sessionId,row.location,row.userAgent]
        cur.execute(songplay_table_insert, songplay_data)


def process_data(cur, conn, filepath, func):
    '''this functions picks up the json file from the filepath, gets the total number of file in each filepath
        and then calls the respective functions that processes the data in the file.'''
    all_files = []
    for root, dirs, files in os.walk(filepath):
        files = glob.glob(os.path.join(root,'*.json'))
        for f in files :
            all_files.append(os.path.abspath(f))

    
    num_files = len(all_files)
    print('{} files found in {}'.format(num_files, filepath))

    
    for i, datafile in enumerate(all_files, 1):
        func(cur, datafile)
        conn.commit()
        print('{}/{} files processed.'.format(i, num_files))


def main():
    conn = psycopg2.connect("host=127.0.0.1 dbname=sparkifydb user=student password=student")
    cur = conn.cursor()

    process_data(cur, conn, filepath='data/song_data', func=process_song_file)
    process_data(cur, conn, filepath='data/log_data', func=process_log_file)

    conn.close()


if __name__ == "__main__":
    main()