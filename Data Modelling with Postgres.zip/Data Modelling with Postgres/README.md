The purpose of Sparkify's analytics team is particularly understand what songs users are listening by analyzing the log data that contains the activities of each user. The database is a star schema with a fact table as songplays which highlights 3 fields/columns i.e. user_id,song_id and artist_id. user_id is tied to users dimension table, song_id is tied to songs dimension table and artist_id is tied to artists dimension table. Querying on these 3 fields will give analytics team clear picture of what songs users are listening to.

Another interesting thing that the analytics team can make out off hand is their paid vs free user base in their app. By looking into fact table(songplays) we can clearly indentify,based on the subset of the data, that there are 22 paid users and 82 free users.The paid user rows in total are 5591 and free user rows are 1229. The good part is the paid user rows are almost 5 times the free user rows but are all 22 paid users heavily use the app ?

Upon further analysis I found out that 5 out of 22 users have less than 100 rows which means 5 users are not liking the recommendation of the next song played by sparkify.We have to reach these 5 users individually and take their suggestions on how we can improve the recommendations to avoid losing them or cancelling theor subscriptions.

Few queries on songplays supporting the above analysis are as follows:

SELECT user_id,count(*) FROM songplays where level='paid' group by user_id;
SELECT count(*) FROM songplays where level='paid';
SELECT user_id,count(*) FROM songplays where level='free' group by user_id;
SELECT count(*) FROM songplays where level='paid';
SELECT  distinct* FROM users where user_id in (70,72,82,20,65); -- these are the 5 users which have less than 100 rows in the log data

Files in the repository:
sql_queries.py - this file is to write postgreSQL queries mainly for create and drop fact and dimension tables.
create_tables.py - this file actually executes the postgreSQL queries written in sql_queries.py file and creates the physical tables in the database
data folder - this consists of the multiple json files for song data and log data in 2 different sub-folders song_data and log_data respectively
etl.ipynb - this file describes step by step ETL process using python data frame scripts on how to read the json files and insert the data into the physical tables created by creat_tables.py file.
etl.py - this file uses the similar python scripts as in etl.ipynb to actually run the entire data in the data folder and inserts the data into the physical tables
test.ipynb - this file gives us the good check to see if the data is inserted or not in the physical tables.

Steps to run the files in console:
Step 1 - run create_tables.py
Step 2 - run etl.py
step 3 - go to test.ipny ans execute each and every script in this file, modify the queries of fact and dimension tables according to your needs of analysis

